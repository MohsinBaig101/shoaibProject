<?php 
define("STRIPE_SECRET_KEY", "sk_test_bfriZ1vZEvtDvCMswH3E3QVU00NTMibIn1");
define("STRIPE_PUBLISHABLE_KEY", "pk_test_j1XBibtaPlwx7HlKBsSbkgod00HrOLU6Gk");
?>